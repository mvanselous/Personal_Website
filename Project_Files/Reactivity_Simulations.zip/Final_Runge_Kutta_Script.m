%%Constants
Rho = 0.00191;                  %% rate of reactivity addition
L = 3.90*10^-5;                 %%prompt neutron life time in s-1
%%P(t) = Reactor Power at time t(W)
%%C(t) = Precursor Power (W)
Gamma = 143.0; %%Change in Specific Heat per degrees Celsius (in J/C^2)
%%Cp(T) = 1.27*10^5+Gamma*(T-25);    %%specific heat fuel in J/Celcius
Beta = 0.007;                   %%Precursor Percentage
Lambda = 0.405;                 %%mean precursor lifetime
%%t = time (in seconds)

h = 0.01;                                                    %% step size
t_max = 4.2;
t_range = 0:h:t_max;                                        %% approximates at given times

Ans_t = zeros(1,length(t_range));

Ans_P = zeros(1,length(t_range));
Ans_C = zeros(1,length(t_range));
Ans_T = zeros(1,length(t_range));
Ans_Cp = zeros(1,length(t_range));

K_1_P = zeros(1,length(t_range));
K_2_P = zeros(1,length(t_range));
K_3_P = zeros(1,length(t_range));
K_4_P = zeros(1,length(t_range));

K_1_C = zeros(1,length(t_range));
K_2_C = zeros(1,length(t_range));
K_3_C = zeros(1,length(t_range));
K_4_C = zeros(1,length(t_range));

K_1_T = zeros(1,length(t_range));
K_2_T = zeros(1,length(t_range));
K_3_T = zeros(1,length(t_range));
K_4_T = zeros(1,length(t_range));

K_1_Cp = zeros(1,length(t_range));
K_2_Cp = zeros(1,length(t_range));
K_3_Cp = zeros(1,length(t_range));
K_4_Cp = zeros(1,length(t_range));

%%Inital Condtions
t_0 = 0; %in seconds
P_0 = 1; %in Watts
C_0 = Beta*P_0/(Lambda*L);
T_0 = 20; %in degrees C
Cp_0 = (1.27*10^5)+Gamma*(T_0-25);

syms t P C T Cp
P_eq = (Rho*t-Beta)/L*P+Lambda*C;
C_eq = Beta/(Lambda*L)*P-Lambda*C;
T_eq = (P-P_0)/Cp;
Cp_eq = Gamma*(P-P_0)/Cp;  % dCp/dt = Gamma * dT/dt

Ans_t(1) = t_0;

Ans_P(1) = P_0; 
Ans_C(1) = C_0; 
Ans_T(1) = T_0; 
Ans_Cp(1) = Cp_0;

for i = 1:(length(t_range))-1
    Ans_t(i+1) = Ans_t(i)+h;
    
    K_1_P(i+1) = subs(P_eq, [t,P,C,T], [Ans_t(i), Ans_P(i), Ans_C(i), Ans_T(i)]); 
    K_1_C(i+1) = subs(C_eq, [t,P,C,T], [Ans_t(i), Ans_P(i), Ans_C(i), Ans_T(i)]); 
    K_1_T(i+1) = subs(T_eq, [t,P,C,T,Cp], [Ans_t(i), Ans_P(i), Ans_C(i), Ans_T(i), Ans_Cp(i)]);
    K_1_Cp(i+1) = subs(Cp_eq, [t,P,Cp], [Ans_t(i), Ans_P(i), Ans_Cp(i)]);
        
    K_2_P(i+1) = subs(P_eq, [t,P,C,T], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_1_P(i+1), Ans_C(i)+(h/2)*K_1_C(i+1), Ans_T(i)+(h/2)*K_1_T(i+1)]);
    K_2_C(i+1) = subs(C_eq, [t,P,C,T], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_1_P(i+1), Ans_C(i)+(h/2)*K_1_C(i+1), Ans_T(i)+(h/2)*K_1_T(i+1)]);
    K_2_T(i+1) = subs(T_eq, [t,P,C,T,Cp], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_1_P(i+1), Ans_C(i)+(h/2)*K_1_C(i+1), Ans_T(i)+(h/2)*K_1_T(i+1), Ans_Cp(i)+(h/2)*K_1_Cp(i+1)]);
    K_2_Cp(i+1) = subs(Cp_eq, [t,P,Cp], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_1_P(i+1), Ans_Cp(i)+(h/2)*K_1_Cp(i+1)]);

    K_3_P(i+1) = subs(P_eq, [t,P,C,T], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_2_P(i+1), Ans_C(i)+(h/2)*K_2_C(i+1), Ans_T(i)+(h/2)*K_2_T(i+1)]);
    K_3_C(i+1) = subs(C_eq, [t,P,C,T], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_2_P(i+1), Ans_C(i)+(h/2)*K_2_C(i+1), Ans_T(i)+(h/2)*K_2_T(i+1)]);
    K_3_T(i+1) = subs(T_eq, [t,P,C,T,Cp], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_2_P(i+1), Ans_C(i)+(h/2)*K_2_C(i+1), Ans_T(i)+(h/2)*K_2_T(i+1), Ans_Cp(i)+(h/2)*K_2_Cp(i+1)]);
    K_3_Cp(i+1) = subs(Cp_eq, [t,P,Cp], [Ans_t(i)+h/2, Ans_P(i)+(h/2)*K_2_P(i+1), Ans_Cp(i)+(h/2)*K_2_Cp(i+1)]);
    
    K_4_P(i+1) = subs(P_eq, [t,P,C,T], [Ans_t(i+1), Ans_P(i)+(h)*K_3_P(i+1), Ans_C(i)+(h)*K_3_C(i+1), Ans_T(i)+(h)*K_3_T(i+1)]);
    K_4_C(i+1) = subs(C_eq, [t,P,C,T], [Ans_t(i+1), Ans_P(i)+(h)*K_3_P(i+1), Ans_C(i)+(h)*K_3_C(i+1), Ans_T(i)+(h)*K_3_T(i+1)]);
    K_4_T(i+1) = subs(T_eq, [t,P,C,T,Cp], [Ans_t(i+1), Ans_P(i)+(h)*K_3_P(i+1), Ans_C(i)+(h)*K_3_C(i+1), Ans_T(i)+(h)*K_3_T(i+1), Ans_Cp(i)+(h)*K_3_Cp(i+1)]);
    K_4_Cp(i+1) = subs(Cp_eq, [t,P,Cp], [Ans_t(i+1), Ans_P(i)+(h)*K_3_P(i+1), Ans_Cp(i)+(h)*K_3_Cp(i+1)]);
    
    Ans_P(i+1) = Ans_P(i) + (h/6)*(K_1_P(i+1)+2*K_2_P(i+1)+2*K_3_P(i+1)+K_4_P(i+1));
    Ans_C(i+1) = Ans_C(i) + (h/6)*(K_1_C(i+1)+2*K_2_C(i+1)+2*K_3_C(i+1)+K_4_C(i+1));
    Ans_T(i+1) = Ans_T(i) + (h/6)*(K_1_T(i+1)+2*K_2_T(i+1)+2*K_3_T(i+1)+K_4_T(i+1));   
    Ans_Cp(i+1) = Ans_Cp(i) + (h/6)*(K_1_Cp(i+1)+2*K_2_Cp(i+1)+2*K_3_Cp(i+1)+K_4_Cp(i+1));  
    end

f1 = figure;
plot(Ans_t, Ans_P);
title('Power vs Time');

f2 = figure;
plot(Ans_t, Ans_C);
title('Precursor Power vs Time');

f3 = figure;
plot(Ans_t, Ans_T);
title('Temperature vs Time');

f4 = figure;
plot(Ans_t, Ans_Cp);
title('Cp vs Time');