%% Description
    %%Ramp Analysis for a reactivty insertion of $0.30 per second
    %%Followed by a scram at 300 kWh (with a 1/2 second delay).
    %%Then the insertion of $9.35 in 1 second. 

%% Set up
Time_Step = 0.0001;
t_vals = (0:Time_Step:25);

Initial_N_Pop = 100;
%% Constants
Fast_Fission_Factor = 1.03;  
    
% Prompt generation time in s-1
L_p = 1*10^-4; 

% Average delayed neutron fraction
B_eff = 0.01386; 

% KWH per fission
Energy_P_Fission = 9.3461111*10^-18;

%% Reactor Specific Values (Modified)

% Fuel Temperature Coefficient
Fuel_Temp_Coeff = -8.25*10^-4; %in p/degrees C

% Core Heat Capacity (constant)
Core_Heat_Cap = 31.4*10^4; % in J/ degrees C

% Dollars away from criticality with all rods inserted
I_Distance_F_Keff = -4.58; 

Worth_Max = I_Distance_F_Keff + 6.78;   %based on rods starting at 0% and an estimate $2.26 of worth per rod

%% Variables
Worth = zeros(1,length(t_vals));
Worth(1) = I_Distance_F_Keff;

Keff = zeros(1,length(t_vals));
Keff(1) = exp(Worth(1)*B_eff);

N_Pop = zeros(1,length(t_vals));
N_Pop(1) = Initial_N_Pop;

kW = zeros(1,length(t_vals));
kW(1) = Energy_P_Fission * N_Pop(1)/(Time_Step);

Fuel_Temp = zeros(1,length(t_vals));
Fuel_Temp(1) = 20;  %in degrees C

Temp_Effect = zeros(1, length(t_vals));
Temp_Contribution = zeros(1, length(t_vals));

%% Reactor Conditions
Scram = false;
Shutdown = false;
Scram_Initiated = -999; %% -999 is a placeholder and bears no significance.

%% Simulation
for i = 1:length(t_vals)-1
    %%Determines dp based on reactor state
    if Shutdown == false
        if Scram == false
           Worth(i+1) = Worth(i)+0.3*Time_Step;
           if Worth(i+1) >= Worth_Max;   Worth(i+1) = Worth_Max;    end
        else
            Worth(i+1) = Worth(i)-0.935*Time_Step;
        end   
    else
        Worth(i+1) = Worth(i);
    end
    
    %%Calculations
    %Temp Contribution
        Fuel_Temp(i+1) = (3.6*10^6)*kW(i)/(Core_Heat_Cap);
        if Fuel_Temp(i+1) <= 20; Fuel_Temp(i+1) = 20; end
        Temp_Effect(i+1) = Fuel_Temp_Coeff*(Fuel_Temp(i+1));
        Temp_Contribution(i+1) = 1+0.001*Temp_Effect(i+1);
    
    %Base Model
    Keff(i+1) = exp(Worth(i+1)*B_eff)*Temp_Contribution(i+1);
    
    N_Pop(i+1) = N_Pop(i)*Keff(i+1)^((Time_Step)/(L_p));
    if N_Pop(i+1) <= 100; N_Pop(i+1) = 100; end
    
    kW(i+1) = Energy_P_Fission*N_Pop(i+1)/(Time_Step);
        
    %%Scram Signal
    if kW(i+1) >= 300
        if Scram_Initiated == -999 
        Scram_Initiated = t_vals(i+1);   
        end
    end
    if t_vals(i+1)-0.5 == Scram_Initiated
            Scram = true;
    end
    if t_vals(i+1)-1.5 == Scram_Initiated
        Shutdown = true;
    end
end

%% Results
figure
semilogy(t_vals,kW);
title('Reactor Power Ramp Analysis');
xlabel('Time (in seconds)');
ylabel('Power (in kW)');

figure
semilogy(t_vals,Fuel_Temp);
title('Fuel Temperature Ramp Analysis');
xlabel('Time(in seconds)');
ylabel('Fuel Temperature (in C)');