%%Mark Van Selous
%%PHYS 273H
%%Honors Project
%%Script 3

%This script is an example for multiple pulses being
%represented through a single Fourier series.

%Although I selected the period (T) of each pulse, I chose values in the
%proximity of the pulses descriebd in my reference textbook. These two
%pulses should also yield a pulse area of pi radians. 

syms t k

h_bar = 1.054571817*10^-34; %in m^2 kg / s
u_01 = 10^-29; %in Cm
A = 11*10^6; %in Vm-1
a = 1;
T_1 = 1.15*10^-12; %in ps
T_2 = 0.55*10^-12; %in ps

C_k = A/(2*sqrt(pi*a))*exp(-(k^2)/(4*a));
F_k_t = C_k*( cos(k*(t-9*10^-12)/T_1)+cos(k*(t-1.75*10^-12)/T_2 ) );
%Note: in practice, the amplitude coefiecents A,B,... are identicle. 
% This allows us to seperate out the, constant with k, pulse offsets.   

F_t = 0;
step = 0.05;
for k_index = -10:step:10
    F_t = F_t + subs(F_k_t,k,k_index)*step;
end

step = 0.025*10^-12;
t_vals = (0:step:12.5*10^-12);

F = zeros(1,length(t_vals));
theta_t = zeros(1,length(t_vals));

for i = 1:length(t_vals)
    F(i) = subs(F_t,t,t_vals(i));
    if i == 1
        theta_t(i) = (u_01/h_bar)*F(i)*step;
    else
        theta_t(i) = theta_t(i-1) + (u_01/h_bar)*F(i)*step;
    end
end

figure
plot(t_vals,F);
title({'Electric Field Amplitude','for a composite wave function'});
xlabel('Time (in ps)');
ylabel('Electric Field Amplitude (in MV m-1)')

figure
plot(t_vals,theta_t);
title({'Pulse Area','for a composite wave functon'});
xlabel('Time (in ps)');
ylabel('Pulse Area (in Rad)')

pulse_area = (theta_t(length(t_vals))); %in radians
fprintf('After applying the pulses, the net pulse area is: %f radians.\n', pulse_area)